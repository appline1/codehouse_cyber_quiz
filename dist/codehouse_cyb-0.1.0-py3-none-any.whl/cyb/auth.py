import time
import requests
from rich.console import Console
from rich.prompt import Prompt
from rich.panel import Panel
from .config import API_LOGIN, API_REGISTER_USER, REMOTE_TIMEOUT, TEMP_TOKEN_EXPIRY_SECONDS, MAX_LOGIN_ATTEMPTS

console = Console()

def register_flow():
    """
    Register a new participant on the website by collecting fullname, email and phone.
    The website is expected to send back a temporary token or accept that it will email a token.
    """
    console.print(Panel.fit("Registration — Create a participant (Fullname, Email, Phone)", title="Register", style="green"))
    fullname = Prompt.ask("Full name").strip()
    email = Prompt.ask("Email").strip()
    phone = Prompt.ask("Phone number").strip()

    payload = {"fullname": fullname, "email": email, "phone": phone}
    try:
        resp = requests.post(API_REGISTER_USER, json=payload, timeout=REMOTE_TIMEOUT)
    except Exception as e:
        console.print(f"[yellow]Network/Registration error:[/yellow] {e}")
        return None, None

    if resp.status_code not in (200, 201):
        console.print(f"[red]Registration failed:[/red] {resp.status_code} {resp.text}")
        return None, None

    data = resp.json()
    # Expected server: returns temp_token (but server may email it instead).
    temp_token = data.get("temp_token")
    console.print("[green]Registration request received. Check your email for a temporary token.[/green]")
    if temp_token:
        console.print("[cyan]Server also returned a temporary token (useful for testing).[/cyan]")
    return email, temp_token

def verify_temp_token_flow(expected_token=None):
    """
    Ask the user to paste the temporary token they received via email.
    - If expected_token is provided (server returned it), accept it for convenience (useful in dev).
    - Token is ephemeral: this function times out after TEMP_TOKEN_EXPIRY_SECONDS.
    """
    start = time.time()
    attempts = 0
    while attempts < MAX_LOGIN_ATTEMPTS and (time.time() - start) < TEMP_TOKEN_EXPIRY_SECONDS:
        tok = Prompt.ask("Enter temporary token (from email) — or type 'cancel'").strip()
        if tok.lower() in ("cancel", "exit", "stop"):
            return False
        if expected_token and tok == expected_token:
            console.print("[green]Token accepted.[/green]")
            return True
        # If server-side verification is desired, you can call an endpoint here.
        # For now we accept the token only if it matches expected_token; otherwise we trust server email token flow.
        console.print("[red]Invalid token. Try again.[/red]")
        attempts += 1

    console.print("[bold red]Temporary token expired or too many attempts.[/bold red]")
    return False

def login_with_sti():
    attempts = 0
    while attempts < MAX_LOGIN_ATTEMPTS:
        sti = Prompt.ask("Enter Student Task ID (STI)").strip()
        password = Prompt.ask("Enter Password", password=True).strip()
        try:
            resp = requests.post(API_LOGIN, json={"sti": sti, "password": password}, timeout=REMOTE_TIMEOUT)
        except Exception as e:
            console.print(f"[yellow]Network error during login:[/yellow] {e}")
            attempts += 1
            continue

        if resp.status_code == 200:
            token = resp.json().get("token")
            console.print(f"[green]Welcome {sti}![/green]")
            return sti, token
        else:
            console.print("[red]Invalid credentials[/red]")
            attempts += 1

    console.print("[bold red]Too many failed attempts. Access denied.[/bold red]")
    raise SystemExit(1)
